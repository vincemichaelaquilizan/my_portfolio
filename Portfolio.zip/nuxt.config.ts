import tailwindcss from '@tailwindcss/vite'
// <meta name='' content=Bqjw5pdkG>
// <meta name="monetag" content="399a7c25ec4a54664ceac1cd096cdf96">
export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',
  app: {
    head: {
      htmlAttrs: {
        lang: 'en' // Important for SEO and accessibility
      },

      // <meta name="viewport" content="width=device-width, initial-scale=1.0">
      meta: [{ name: 'viewport', content: 'width=device-width, initial-scale=1.0' }],
      // <meta name="viewport" content="width=1280">
      title: 'Free QR Code Generator — No Login, Unlimited & Permanent'
    }
  },
  // Modules & Styling
  modules: [
    '@nuxt/eslint',
    '@nuxt/image',
    '@nuxt/scripts',
    '@nuxt/content',
    '@nuxt/hints',
    '@nuxtjs/sitemap' // Recommended: install this module for better SEO
  ],

  css: ['./app/assets/css/main.scss'],

  vite: {
    plugins: [tailwindcss()],
    optimizeDeps: {
      include: ['@vue/devtools-core', '@vue/devtools-kit']
    }
  },
  devtools: { enabled: true }
})
