<script setup>
import NavBar from './components/reuse/navBar.vue'
import { onMounted, ref } from 'vue'

const isLoading = ref(true)

onMounted(() => {
  console.log('Component mounted → page is loading...')

  if (document.readyState === 'complete') {
    isLoading.value = false
    console.log('Page already loaded')
  } else {
    window.addEventListener('load', () => {
      isLoading.value = false
      console.log('Page fully loaded')
    })
  }
})
</script>

<template>
  <!--  <div v-if="!isLoading" class="page-bg"> -->
  <NavBar />
  <NuxtPage />
  <div class="firstBg">
    <TitlePage />
    <AboutMe />
  </div>
  <div class="secondBg">
    <MyContent />
  </div>
  <!-- </div> -->
</template>
