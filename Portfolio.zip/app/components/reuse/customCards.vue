<template>
  <div class="card" @mouseenter="$emit('mouseenter')" @mouseleave="$emit('mouseleave')">
    <div class="card-image" v-if="!isUsingMobile || !isVisible">
      <img src="https://picsum.photos/400/300" alt="random image" />
    </div>

    <div class="card-content" v-if="!isUsingMobile || isVisible">
      <h1>Lorem Ipsum</h1>
      <p>Ipsum dolor sit amet, consectetur adipiscing elit...</p>
      <a :href="url" target="_blank" rel="noopener noreferrer" class="btn">Read More</a>
    </div>
  </div>
</template>

<script setup>
defineEmits(['mouseenter', 'mouseleave'])
defineProps({
  isVisible: Boolean,
  url: String
})

const isUsingMobile = ref(false)

onMounted(() => {
  isUsingMobile.value = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)
})
</script>

<style lang="scss" scoped>
.hideImage {
  display: none;
}
.card {
  max-width: 400px;
  background: linear-gradient(to right, rgba(255, 255, 255, 1), rgba(255, 255, 255, 0));
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease;
  cursor: pointer;
  .card-image {
    width: 100%;
    height: 200px;
    position: relative;

    padding: 1rem;
    img {
      width: 100%;
      height: 100%;
      object-fit: cover; /* Prevents image distortion */
    }
  }

  .card-content {
    display: flex;
    flex-direction: column;
    gap: 1rem;
    padding: 1.5rem;
    h1 {
      margin: 0;
      font-size: 1.5rem;
      color: #334155;
    }

    p {
      margin: 0;
      font-size: 0.95rem;
      line-height: 1.6;
      color: #64748b;
    }

    .btn {
      align-self: flex-start;
      text-decoration: none;
      font-weight: 600;
      color: #3b82f6;
      transition: color 0.2s;
      font-size: 1.3rem;

      &:hover {
        color: #1d4ed8;
      }
    }
  }

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.18);
  }
}

/* Simple mobile adjustment */
@media (max-width: 768px) {
  .card-content {
    p {
      font-size: 0.75rem !important;
    }
  }
  .card {
    .card-image {
      width: 100%;
      // height: 100%;
    }
  }
}
@media (hover: none) {
  .card:hover {
    transform: none;
    box-shadow: none;
  }
}
</style>
