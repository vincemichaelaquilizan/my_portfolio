<template>
  <div class="progress-container">
    <div class="labels">
      <span>Beginner</span>
      <span class="active">Intermediate</span>
      <span>Advanced</span>
    </div>

    <div class="progress-bar">
      <div class="progress-fill intermediate"></div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
$color-beginner: #4caf50;
$color-intermediate: #ff9800;
$color-advanced: #f44336;

.progress-container {
  width: 100%;
  max-width: 800px;

  .labels {
    display: flex;
    justify-content: space-between;
    margin: 10px 0 10px 0;
    // flex-wrap: ;
    gap: 10px;
    span {
      // prevents too small text
      //    fon

      font-size: 1rem;
    }
    .active {
      font-weight: bold;
    }
  }

  .progress-bar {
    width: 100%;
    height: 20px;
    background-color: #eee;
    border-radius: 10px;
    overflow: hidden;

    .progress-fill {
      height: 100%;
      width: 60%; // change level
      border-radius: 10px;
      transition: width 0.4s ease;

      &.beginner {
        background-color: $color-beginner;
      }

      &.intermediate {
        background-color: $color-intermediate;
      }

      &.advanced {
        background-color: $color-advanced;
      }
    }
  }
}
@media (max-width: 600px) {
  .progress-container {
    padding: 0 10px;

    .labels {
      gap: 4px;

      span {
        font-size: 0.75rem; /* smaller text */
      }
    }

    .progress-bar {
      height: 12px; /* thinner bar for mobile */
      border-radius: 8px;
    }
  }
}
</style>
