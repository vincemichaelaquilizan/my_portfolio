<template>
  <div class="mangaBorder left"></div>
  <div class="mangaBorder right"></div>
</template>

<style lang="scss" scoped>
.mangaBorder {
  position: absolute;
  top: 0;
  height: 100%;
  width: 20vh;

  background-image: radial-gradient(circle, black 20%, transparent 20%);
  background-size: 10px 10px;

  z-index: 0;
  mix-blend-mode: soft-light;
  opacity: 0.8;

  &.left {
    left: 0;
    mask-image: linear-gradient(to right, black, transparent);
    -webkit-mask-image: linear-gradient(to right, black, transparent);
  }

  &.right {
    right: 0;
    mask-image: linear-gradient(to left, black, transparent);
    -webkit-mask-image: linear-gradient(to left, black, transparent);
  }
}
</style>
