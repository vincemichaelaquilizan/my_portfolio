<template>
  <nav class="navbar" :class="{ 'navbar--hidden': !isVisible }">
    <div class="navbar-content">
      <div class="logo"><p class="name">Vince Michael Aqilizan</p></div>
      <ul class="nav-links">
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </div>
  </nav>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

const isVisible = ref(false)

const handleScroll = () => {
  // Show navbar only if scrolled more than 100px from the top
  isVisible.value = window.scrollY > 200
}

onMounted(() => {
  window.addEventListener('scroll', handleScroll)
})

onUnmounted(() => {
  window.removeEventListener('scroll', handleScroll)
})
</script>

<style lang="scss" scoped>
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1000;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px); // Modern glass effect
  border-bottom: 5px solid rgba(0, 0, 0, 0.1);
  padding: 0 40px;
  height: 70px;
  display: flex;
  align-items: center;
  transition:
    transform 0.4s cubic-bezier(0.16, 1, 0.3, 1),
    opacity 0.3s ease;
  &--hidden {
    transform: translateY(-100%);
    opacity: 0;
    pointer-events: none;
  }
}

.navbar-content {
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  font-size: 1.5rem;
  font-weight: 800;
  letter-spacing: -1px;
  color: #000;
}

.nav-links {
  list-style: none;
  display: flex;
  gap: 40px; // Modern way to handle spacing instead of margins
  margin: 0;
  padding: 0;

  a {
    text-decoration: none;
    color: #333;
    font-size: 0.95rem;
    font-weight: 500;
    transition: all 0.2s ease;
    position: relative;

    // Subtle underline hover effect
    &::after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 0%;
      height: 2px;
      background: #f39c12;
      transition: width 0.3s ease;
    }

    &:hover {
      color: #f39c12;
      &::after {
        width: 100%;
      }
    }
  }
}
</style>
