<script setup>
const props = defineProps({
  label: {
    type: String,
    required: true
  }
})

const currentText = ref(props.label)
</script>

<template>
  <p class="details">{{ currentText }}</p>
</template>

<style lang="scss" scoped>
$font-body: 'Saira', sans-serif;

.details {
  margin: 0;
  padding: 10px;
  border-radius: 30px;
  background-color: rgba(0, 0, 0, 0.9);
  text-align: center;
  font-family: $font-body;
  font-size: clamp(16px, 2vw, 30px);
}
</style>
