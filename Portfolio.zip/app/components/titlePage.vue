<script setup lang="ts">
import ComicBorder from './reuse/comicBorder.vue'
import LabelPageTitle from './reuse/labelPageTitle.vue'
</script>

<template>
  <div class="box">
    <p class="name">Vince Michael Aqilizan</p>
    <div class="bg box1"></div>
    <div class="bg box2"></div>
    <img class="airplane" src="/image/airplane.png" />
    <img class="mzd" src="/image/MZD_28.webp" />
    <img class="city" src="/image/City_Silhouette_Clipart.png" />
    <div class="myContainer">
      <h3 class="year shadow">2026</h3>
      <h1 class="title shadow">PORTFOLIO</h1>
      <LabelPageTitle label="{ programmer | web developer | game developer | artist }" />
    </div>
    <ComicBorder />
  </div>
</template>

<style lang="scss" scoped>
// @import url('./../assets/css/animation/title.css');

// VARIABLES
$font-title: 'Bungee', sans-serif;
$font-body: 'Saira', sans-serif;
// MIXINS

@mixin abs-center {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
}

@mixin main-box-bg {
  position: absolute;
  width: 50rem;
  height: 50rem;
  background-color: rgba(0, 0, 0, 0.144);
  z-index: 1;
}

// BASE CONTAINER
.box {
  position: relative;
  width: 100%;
  height: 90svh; /* 👈 stable */
  overflow: hidden;
  display: flex;
  align-items: center;
}

// CONTENT
.myContainer {
  position: relative;
  z-index: 5;
  height: auto;
  width: 70dvw;
  display: flex;
  flex-direction: column;
  // justify-content: center;
  // align-items: center;
  margin: 0 10px 0 10px;
  color: white;
}
// TYPOGRAPHY
.year,
.title {
  font-family: $font-title;
}

.year {
  font-size: 5dvw;
}

.title {
  font-size: 10dvw;
}

.shadow {
  -webkit-text-stroke: 2px rgba(0, 0, 0, 0.507);
  text-shadow: 5px 5px 0 rgba(0, 0, 0, 0.8);
}
// IMAGES
.airplane {
  position: absolute;
  top: 10vh;
  left: 20vw;

  mix-blend-mode: color-dodge;
  opacity: 0.6;
}

.mzd {
  position: absolute;
  bottom: 20%;
  left: 80vw;

  transform: scaleX(-1) scale(2.5);
  z-index: 3;
}

.city {
  position: absolute;
  bottom: -1px;
  transform-origin: bottom center;
  width: 100%;

  transform: scaleX(1.2);
  opacity: 0.7;
  mix-blend-mode: multiply;
  z-index: 2;
}

// BACKGROUND BOXES
.bg {
  @include main-box-bg;
}

.box1 {
  top: 50%;
  left: 0;
  transform: translate(-50%, -50%) rotate(33.5deg) scaleX(5);
}

.box2 {
  top: 50%;
  left: 100%;
  transform: translate(-50%, -50%) rotate(145.5deg) scaleX(5);
}

// RESPONSIVE
@media (max-width: 768px) {
  .name {
    font-size: 5dvw;
  }
  .year {
    font-size: 10dvw;
  }
  .title {
    font-size: 15dvw;
  }

  .details {
    // margin: 0 10px 10px 0px !important;
    margin-right: 5vw;
    align-items: center;
    justify-items: center;
    font-size: 5dvw;
    padding: 15px;
    background-color: rgba(0, 0, 0, 0.5);
  }

  .myContainer {
    margin-top: 10%;
    width: 100%;
    justify-content: left; /* vertical alignment */
  }

  .airplane {
    transform: scale(0.7);
    left: -30vw;
  }

  .mzd {
    bottom: 0;
    left: 30%;
    transform: scaleX(-1) scale(1);
  }

  .city {
    transform: scale(2);
    // bottom: 8%;
  }

  // FIXED: correct selector targeting
  .box1 {
    left: -50%;
    top: 100%;
  }

  .box2 {
    left: 150%;
    top: 100%;
  }
}
</style>
