<script setup lang="ts">
import BoxIcons from './reuse/boxIcons.vue'
import ComicBorder from './reuse/comicBorder.vue'
import ProgressBar from './reuse/progressBar.vue'
</script>

<template>
  <div class="box">
    <div class="myAbout cornered">
      <div class="wrapper">
        <h1 class="title">About me</h1>
        <br />
        <div class="content">
          <p>
            <b>Hi!</b>
            ipsum dolor sit amet, consectetur adipiscing elit. Aliquam rhoncus odio mauris, in
            dictum risus facilisis in. Cras in nunc sapien. Nam eu sapien sagittis, suscipit quam a,
            ultrices neque. Maecenas scelerisque lacus ac sapien faucibus bibendum. Quisque at est a
            augue vulputate accumsan ut in quam. Etiam dignissim libero turpis, ac vulputate libero
            finibus quis.ipsum dolor sit amet, consectetur adipiscing elit. Aliquam rhoncus odio
            mauris, in dictum risus facilisis in. Cras in nunc sapien. Nam eu sapien sagittis,
            suscipit quam a, ultrices neque. Maecenas scelerisque lacus ac sapien faucibus bibendum.
            Quisque at est a augue vulputate accumsan ut in quam. Etiam dignissim libero turpis, ac
            vulputate libero finibus quis.
            <br />
            <br />
          </p>
          <div class="profileInfo">
            <img class="profile" src="/image/1000001131-CZAOabSW.jpg" />
            <p>Email: sample@gmail.com</p>
            <p>Email: sample@gmail.com</p>
          </div>
          <!-- <br /> -->
        </div>
        <hr />
        <br />
        <div class="content specializationSkill">
          <div class="background">
            <div class="education">
              <h1>Education</h1>

              <br />
              <p>
                ipsum dolor sit amet, consectetur adipiscing elit. Aliquam rhoncus odio mauris,
                in<br />
                dictum risus facilisis in. Cras in nunc sapien. Nam eu sapien sagittis, suscipit
                quam a, ultrices
              </p>
            </div>
            <br />
            <hr />
            <br />
            <div class="Skills">
              <h1>Skills</h1>
              <br />
              <ul>
                <li>List 1</li>
                <li>List 1</li>
                <li>List 1</li>
                <li>List 1</li>
              </ul>
            </div>
          </div>
          <div class="specialization">
            <h1>Specialized</h1>
            <BoxIcons />
            <BoxIcons />
            <BoxIcons />
            <BoxIcons />
          </div>
          <div class="otherSkills">
            <h3>Other skills</h3>
            <ProgressBar />
            <ProgressBar />
            <ProgressBar />
          </div>
        </div>
      </div>
    </div>

    <ComicBorder />
    <img class="city" src="/image/image.png" />
  </div>
</template>
<style lang="scss" scoped>
.center-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
}
.box {
  display: flex;
  justify-content: center;
  width: 100%;
  min-height: 80dvh;
  position: relative;
  overflow: hidden;
}

.profileInfo {
  // margin: ;
  text-align: center;
  p {
    margin: 20px;
  }
}
.myAbout {
  transform: scale(0.95);
  position: relative;
  width: 80vw;
  height: auto;
  background-color: white;
  z-index: 5;
  margin-top: 5%;
  margin-bottom: 2.5%;
  padding: 80px;
  align-items: center; /* 🔥 add this */
  justify-content: center;
  border-radius: 40px;
  box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.3);
}

.title {
  font-family: 'Borel', cursive;
  color: rgb(48, 48, 48);
  font-weight: 600;
}

/* ✅ FIXED layout */
.specializationSkill {
  display: flex; // 🔥 REQUIRED
  // gap: 100px;       // optional spacing

  .background {
    p {
      font-size: 1.2rem;
    }
    // flex-basis: 50px;
    flex: 4;
  }
  .specialization {
    flex: 3;
    text-align: center;
    top: 0;
    gap: 10px;
    // flex-grow: 1;
  }
  .otherSkills {
    // padding:;
    flex: 2;
  }
}
ul {
  display: flex;
  flex-wrap: wrap;
  padding: 0;
  margin: 0;
  li {
    list-style: none;
    width: 25%; /* 4 per row */
    box-sizing: border-box;

    font-size: 1.2rem;
  }
}

.content {
  height: fit-content;
  display: flex;
  gap: 50px;
  align-items: center;
  p {
    display: block; // ✅ keep flex
    gap: 10px;
    flex: 1;
    line-height: 2.5rem;
    font-size: 1rem;
    align-items: center;
    b {
      font-size: 60px;
      font-family: 'Bungee', sans-serif;
      line-height: 1; // 🔥 important
    }
  }
}
/* profile image */
.profile {
  flex-shrink: 0; /* prevents squeezing */
  width: 300px;
  height: 300px;
  border-radius: 30%;
  object-fit: cover;
  object-position: 50% 20%;
}

/* city background */
.city {
  // border: 2px solid red;
  position: absolute;
  width: 100%;
  // top: -10px;
  transform-origin: top center;
  transform: perspective(400px) rotateX(20deg);
  opacity: 0.9;
  mix-blend-mode: multiply;
  z-index: 2;
  mask-image: linear-gradient(to top, rgba(0, 0, 0, 1), rgba(0, 0, 0, 0));
  -webkit-mask-image: linear-gradient(to top, rgba(0, 0, 0, 0), rgba(0, 0, 0, 1));
}

/* mobile responsive */
@media (max-width: 768px) {
  .content {
    flex-direction: column;
    align-items: center;
    p {
      font-size: 0.8rem;
      b {
        font-size: 40px;
      }
    }
  }
  .specializationSkill {
    gap: 2;
    .background {
      p {
        font-size: 0.9rem;
      }
    }

    .otherSkills {
      // padding: ;
    }
  }
  .profileInfo {
    order: -1;
  }
  .profile {
    width: 200px;
    height: 200px;
    /* ✅ makes image go on top */
  }

  .myAbout {
    margin: 10%;
    padding: 30px;
  }

  .city {
    // bottom: 0;
    top: 0;
    transform: perspective(600px) rotateX(60deg) scaleX(2);
    // transform: perspective(250px) rotateX(40deg) scaleX(2) scaleY(-2);
  }
}
</style>
