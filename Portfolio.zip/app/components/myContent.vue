<script setup lang="ts">
import { ref } from 'vue'

import ComicBorder from './reuse/comicBorder.vue'
import CustomCards from './reuse/customCards.vue'
import LabelPageTitle from './reuse/labelPageTitle.vue'

const cards = ref([
  {
    id: 1,
    type: 'web',
    content: [
      { id: 1, url: 'https://www.facebook.com/' },
      { id: 2, url: 'https://x.com/yuz_mynerva0x13' },
      { id: 3, url: 'https://x.com/yuz_mynerva0x13' },
      { id: 4, url: 'https://x.com/yuz_mynerva0x13' }
    ]
  }
  // Add more project groups here if needed
])

const activeCardId = ref<number | null>(null)

const showCard = (id: number) => {
  activeCardId.value = id
}
</script>

<template>
  <div class="box">
    <LabelPageTitle label="Showcase Project" class="label" />
    <ul>
      <li>
        <a>Web Dev</a>
      </li>
      <li>
        <a>Games</a>
      </li>
    </ul>
    <div v-for="card in cards" :key="card.id" style="width: auto">
      <div :class="card.type">
        <div class="myWorkingProject" @mouseleave="activeCardId = null">
          <CustomCards
            v-for="listCard in card.content"
            :key="listCard.id"
            :url="listCard.url"
            :is-visible="activeCardId === listCard.id"
            @mouseenter="showCard(listCard.id)"
          />
        </div>
      </div>
    </div>

    <ComicBorder />
  </div>
</template>

<style lang="scss" scoped>
.myWorkingProject {
  width: 80vw;
  display: grid;
  grid-template-columns: repeat(2, 500px);
  gap: 20px;
  justify-content: center;
}
.label {
  color: white;
  padding: 10px 100px 10px 100px;
  margin: 2.5% 0 5% 0;
}
.box {
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  min-height: 100dvh;
  position: relative;
  overflow: hidden;
  flex-direction: column;
}

@media (max-width: 768px) {
  .myWorkingProject {
    flex-direction: column;
    align-items: center;

    grid-template-columns: 300px;
    .card {
      width: 300px;
      height: 200px;
    }
  }
}
</style>
